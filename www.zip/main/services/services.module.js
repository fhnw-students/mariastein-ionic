(function () {
  'use strict';

  angular.module('kmsscan.services', [

    'kmsscan.services.BarcodeScanner',
    'kmsscan.services.Data'

  ]);

}());