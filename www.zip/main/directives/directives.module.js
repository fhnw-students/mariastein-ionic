(function () {
  'use strict';

  angular.module('kmsscan.directives', [

    'kmsscan.directives.NavMenuButton',
    'kmsscan.directives.ScanButton'

  ]);

}());